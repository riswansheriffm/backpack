﻿namespace BackPack.Dependency.Library.Responses
{
    public class DBQueryDataCountResponse
    {
        public int ActivityCount { get; set; }
    }
}
