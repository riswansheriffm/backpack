﻿namespace BackPack.APIGateway.Cors
{
    public class CorsSettings
    {
        public string? Php { get; set; }
        public string? React { get; set; }
    }
}
