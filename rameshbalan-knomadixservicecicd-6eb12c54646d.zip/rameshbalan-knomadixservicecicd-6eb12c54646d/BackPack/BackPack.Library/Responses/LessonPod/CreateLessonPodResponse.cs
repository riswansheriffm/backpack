﻿using BackPack.Dependency.Library.Responses;

namespace BackPack.Library.Responses.LessonPod
{
    public class CreateLessonPodResponse : BaseResponse
    {
        public int LessonUnitID { get; set; }
    }
}
