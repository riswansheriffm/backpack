﻿using BackPack.Dependency.Library.Responses;

namespace BackPack.Library.Responses.LessonPod
{
    public class CreateLessonPodSlideTemplateResponse : BaseResponse
    {
        public int SlideTemplateID { get; set; }
    }
}
