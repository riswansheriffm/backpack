﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideHotspotResponse : BaseControlResponse
    {
        public List<HotSpotArrayResponse>? HotSpot { get; set; }
    }
}
