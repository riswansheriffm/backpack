﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideRotatingDialResponse : BaseControlResponse
    {
        public float? Answers { get; set; }
    }
}
