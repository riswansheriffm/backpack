﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideMatchParentResponse : BaseControlResponse
    {
        public List<SmartSlideMatchingExerciseOptionsResponse>? Options { get; set; }
    }
}
