﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideCategoryAnswerResponse
    {
        public bool? IsDecoy { get; set; }
        public string? Key { get; set; }
        public string? Value { get; set; }
    }
}
