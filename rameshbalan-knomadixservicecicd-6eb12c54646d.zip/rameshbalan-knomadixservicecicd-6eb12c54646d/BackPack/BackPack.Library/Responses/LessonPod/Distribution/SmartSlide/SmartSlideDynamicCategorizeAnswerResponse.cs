﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideDynamicCategorizeAnswerResponse
    {
        public bool? IsDecoy { get; set; }
        public string? Answer { get; set; }
    }
}
