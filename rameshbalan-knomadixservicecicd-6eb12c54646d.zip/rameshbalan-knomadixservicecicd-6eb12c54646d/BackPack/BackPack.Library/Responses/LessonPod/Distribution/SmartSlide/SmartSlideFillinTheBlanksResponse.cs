﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideFillinTheBlanksResponse : BaseControlResponse
    {
        public List<string>? Answers { get; set; }
    }
}
