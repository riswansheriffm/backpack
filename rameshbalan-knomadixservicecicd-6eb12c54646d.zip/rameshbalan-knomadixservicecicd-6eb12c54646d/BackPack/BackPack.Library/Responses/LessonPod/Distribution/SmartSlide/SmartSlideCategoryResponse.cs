﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideCategoryResponse : BaseControlResponse
    {
        public List<SmartSlideCategoryOptionResponse>? Options { get; set; }
    }
}
