﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideCategoryOptionResponse
    {
        public SmartSlideCategoryQuestionResponse? Question { get; set; }
        public List<SmartSlideCategoryAnswerResponse>? Answers { get; set; }
    }
}
