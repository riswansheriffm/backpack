﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideMatchTableResponse : BaseControlResponse
    {
        public List<List<string>>? Answers { get; set; }
    }
}
