﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideArrangeResponse : BaseControlResponse
    {
        public List<OptionControlResponse>? Answers { get; set; }
    }
}
