﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideDynamicCategoryResponse : BaseControlResponse
    {
        public List<SmartSlideDynamicCategorizeArrayResponse>? HotSpot { get; set; }
    }
}
