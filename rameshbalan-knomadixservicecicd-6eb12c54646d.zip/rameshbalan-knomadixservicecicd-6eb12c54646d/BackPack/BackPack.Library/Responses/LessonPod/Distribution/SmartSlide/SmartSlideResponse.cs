﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideResponse
    {
        public float TotalScore { get; set; }
        public List<object>? InputControls { get; set; }
    }
}
