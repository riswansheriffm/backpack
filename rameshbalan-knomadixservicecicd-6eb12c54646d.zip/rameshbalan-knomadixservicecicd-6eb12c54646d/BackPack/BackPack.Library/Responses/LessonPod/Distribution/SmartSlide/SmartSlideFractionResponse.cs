﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideFractionResponse : BaseControlResponse
    {
        public string? Answers { get; set; }
    }
}
