﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideMatchingExerciseOptionsResponse
    {
        public SmartSlideMatchingExerciseOptionResponse? OptionLeft { get; set; }
        public SmartSlideMatchingExerciseOptionResponse? OptionRight { get; set; }
    }
}
