﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideMatchingExerciseOptionResponse
    {
        public string? OptionValue { get; set; }
    }
}
