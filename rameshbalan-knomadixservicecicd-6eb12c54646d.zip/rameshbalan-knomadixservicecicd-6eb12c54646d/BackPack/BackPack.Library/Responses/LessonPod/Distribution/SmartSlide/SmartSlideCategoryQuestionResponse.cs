﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartSlide
{
    public class SmartSlideCategoryQuestionResponse
    {
        public float? Score { get; set; }
        public string? Value { get; set; }
    }
}
