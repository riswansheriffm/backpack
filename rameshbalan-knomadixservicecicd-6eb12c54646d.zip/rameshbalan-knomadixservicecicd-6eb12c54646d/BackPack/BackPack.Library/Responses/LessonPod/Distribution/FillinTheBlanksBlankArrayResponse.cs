﻿namespace BackPack.Library.Responses.LessonPod.Distribution
{
    public class FillinTheBlanksBlankArrayResponse
    {
        public int? Blank { get; set; }
        public List<string>? Option { get; set; }
    }
}
