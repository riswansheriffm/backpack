﻿namespace BackPack.Library.Responses.LessonPod.Distribution
{
    public class OptionControlResponse
    {
        public string? Option { get; set; }
    }
}
