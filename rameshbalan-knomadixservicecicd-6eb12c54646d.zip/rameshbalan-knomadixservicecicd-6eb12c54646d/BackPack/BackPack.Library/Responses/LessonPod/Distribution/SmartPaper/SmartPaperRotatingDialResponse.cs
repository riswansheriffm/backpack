﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperRotatingDialResponse : BaseControlResponse
    {
        public float? Answers { get; set; }
    }
}
