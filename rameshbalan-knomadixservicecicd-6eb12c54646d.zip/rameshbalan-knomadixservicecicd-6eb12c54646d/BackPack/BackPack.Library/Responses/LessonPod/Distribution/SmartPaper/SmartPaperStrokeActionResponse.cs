﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperStrokeActionResponse
    {
        public int StrokeID { get; set; }
        public string? Action { get; set; }
    }
}
