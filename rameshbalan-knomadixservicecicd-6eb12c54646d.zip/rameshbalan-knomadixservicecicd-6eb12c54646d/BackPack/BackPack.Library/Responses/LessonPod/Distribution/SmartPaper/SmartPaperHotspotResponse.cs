﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperHotspotResponse : BaseControlResponse
    {
        public List<HotSpotArrayResponse>? HotSpot { get; set; }
    }
}
