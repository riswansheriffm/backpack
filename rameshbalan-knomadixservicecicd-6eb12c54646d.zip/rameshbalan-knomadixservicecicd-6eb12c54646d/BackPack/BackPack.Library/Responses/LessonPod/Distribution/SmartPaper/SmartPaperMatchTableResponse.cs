﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperMatchTableResponse : BaseControlResponse
    {
        public List<List<string>>? Answers { get; set; }
    }
}
