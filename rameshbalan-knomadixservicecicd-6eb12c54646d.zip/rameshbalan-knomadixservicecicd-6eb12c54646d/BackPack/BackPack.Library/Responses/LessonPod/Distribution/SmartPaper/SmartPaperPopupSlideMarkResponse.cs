﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperPopupSlideMarkResponse
    {
        public string? MarkerName { get; set; }
        public string? MarkerType { get; set; }
        public string? MarkerValue { get; set; }
    }
}
