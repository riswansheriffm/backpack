﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperFractionResponsecs : BaseControlResponse
    {
        public string? Answers { get; set; }
    }
}
