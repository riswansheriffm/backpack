﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperListDataResponse
    {
        public string? Answer { get; set; }
        public string? Value { get; set; }
    }
}
