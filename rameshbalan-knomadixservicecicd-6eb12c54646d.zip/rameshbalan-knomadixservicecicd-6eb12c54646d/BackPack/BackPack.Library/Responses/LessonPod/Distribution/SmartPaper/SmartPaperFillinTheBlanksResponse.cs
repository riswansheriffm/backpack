﻿namespace BackPack.Library.Responses.LessonPod.Distribution.SmartPaper
{
    public class SmartPaperFillinTheBlanksResponse : BaseControlResponse
    {
        public List<string>? Answers { get; set; }
    }
}
