﻿namespace BackPack.Library.Responses.LessonPod.Distribution
{
    public class PlayerMarkResponse
    {
        public string? MarkerName { get; set; }
        public string? Seconds { get; set; }
        public string? MarkerType { get; set; }
        public string? MarkerValue { get; set; }
    }
}
