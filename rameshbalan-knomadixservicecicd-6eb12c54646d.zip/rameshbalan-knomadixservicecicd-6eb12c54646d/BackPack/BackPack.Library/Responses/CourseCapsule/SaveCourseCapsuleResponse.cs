﻿using BackPack.Dependency.Library.Responses;

namespace BackPack.Library.Responses.CourseCapsule
{
    public class SaveCourseCapsuleResponse : ReadBaseResponse
    {
        public int CourseCapsuleID { get; set; }
    }
}
