﻿
namespace BackPack.Library.Constants
{
    public static class RouteConstant
    {
        #region User
        public const string RouteCreateSuperUser = "CreateSuperUser";
        public const string RouteDeleteStudent = "DeleteStudent";
        #endregion        
    }
}
