﻿
namespace BackPack.Library.Requests.User
{
    public class SuperUserRequest : UserRequest
    {

    }
}
